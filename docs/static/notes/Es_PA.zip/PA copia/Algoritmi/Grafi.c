#include <stdio.h>
#define ROW 6
#define COL 6

int colorato(int matrice[ROW][COL], int A[ROW]);
void triangoli(int matrice[ROW][COL]);

int main()
{

    int matrice[ROW][COL] = {
        {0, 1, 1, 1, 0, 0},
        {1, 0, 1, 1, 1, 0},
        {1, 1, 0, 0, 0, 0},
        {1, 1, 0, 0, 1, 1},
        {0, 1, 0, 1, 0, 1},
        {0, 0, 0, 1, 1, 0}};
}

int **quadrato(int matrice[ROW][COL])
{

    int matrice_quadrato[ROW][COL];
    for (int i = 0; i < COL; i++)
        for (int j = 0; j < COL; j++)
            if (matrice[i][j] == 1)
                for (int k = 0; k < COL; k++)
                    if (matrice[j][k] == 1)
                        matrice_quadrato[i][k] = 1;
    return matrice_quadrato;
}



#define POZZO 1
#define NO_POZZO 0
int pozzo(int matrice[ROW][COL])
{

    int candidato = 0;
    for (int i = 1; i < COL; i++)
        if (matrice[candidato][i] == 1)
            candidato = i;

    for (int i = 0; i < COL; i++)
        if (candidato != i)
            if (matrice[candidato][i] == 1 || matrice[i][candidato] == 0)
                return NO_POZZO;

    return POZZO;
}

void triangoli(int matrice[ROW][COL])
{
    int triangoli = 0;

    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COL; j++)
            if (matrice[i][j] == 1)
                for (int k = 0; k < COL; k++)
                    if (matrice[j][k] == 1 && matrice[i][k] == 1)
                    {
                        triangoli++;
                        printf("Triangolo (%d,%d) , (%d , %d) , (%d , %d)\n", i + 1, j + 1, j + 1, k + 1, i + 1, k + 1);
                    }

    printf("Numero triangoli: %d\n", triangoli / 6);
}

#define NO 0
#define SI 1
int colorato(int matrice[ROW][COL], int A[ROW])
{
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COL; j++)
            if (matrice[i][j] == 1)
                if (A[i] == A[j])
                    return NO;
    return SI;
}

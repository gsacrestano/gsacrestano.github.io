#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define UNDEFINED -1
int longestPalindrome(int table[50][50], char *str, int s, int e)
{
    if (e < s)
        return 0;
    if (s == e)
        return 1;
    if (table[s][e] == UNDEFINED)
    {
        char *start = str + s;
        char *end = str + e;
        if (*start == *end)
            table[s][e] = 2 + longestPalindrome(table, str, s + 1, e - 1);
        else
        {
            int withFirst = longestPalindrome(table, str, s, e - 1);
            int withLast = longestPalindrome(table, str, s + 1, e);
            // Put into table the max between the 2 choice
            table[s][e] = withFirst > withLast ? withFirst : withLast;
        }
    }
    return table[s][e];
}

#define UNDEFINED -1
int maxProfit(int table[50][50], int *array, int arraySize, int n)
{
    if (n == 0)
        return 0;
    if (arraySize == 1)
        return n * *(array);
    if (table[arraySize][n] == UNDEFINED)
    {
        // Check if the longest could be taken
        if (n < arraySize)
            table[arraySize][n] = maxProfit(table, array, arraySize - 1, n);
        else
        {
            int withLongest = *(array + arraySize - 1) + maxProfit(table, array, arraySize, n - arraySize);
            int withoutLongest = maxProfit(table, array, arraySize - 1, n);
            // Put into table the max between the 2 choice
            table[arraySize][n] = withLongest > withoutLongest ? withLongest : withoutLongest;
        }
    }
    return table[arraySize][n];
}

int griglia(int table[50][50], int x, int y, int n)
{
    if (x == 0 || y == n - 1)
        return 1;
    if (table[x][y] == UNDEFINED)
    {
        int right = griglia(table, x - 1, y, n);
        int up = griglia(table, x, y + 1, n);
        table[x][y] = right + up;
    }
    return table[x][y];
}

int prodottoIndici(int array[], int s, int e, int N)
{
    if (e < s)
        return 0;
    int val = array[s] * array[e];

    if (s == e || e - s == 1)
        return val == N;

    if (val == N)
        return 1;

    if (val > N)
        return prodottoIndici(array, s, e - 1, N);
    return prodottoIndici(array, s + 1, e, N);
}

int max(int array[], int s, int e)
{

    int max = array[s];
    for (int i = s; i != e + 1; i++)
        if (array[i] > max)
            max = array[i];

    printf(" - Max [%d]-[%d]: %d\n", s, e, max);
    return max;
}
int min(int array[], int s, int e)
{
    int min = array[s];
    for (int i = s; i != e + 1; i++)
        if (array[i] < min)
            min = array[i];

    printf("Min [%d] - [%d]: %d", s, e, min);
    return min;
}

int azioniACME(int *array, int s, int e)
{
    // Input: array [356] where a[0] > a[364]
    if (e - s == 1)
        return e;
    int mid = (s + e) / 2;
    // Output: index i where a[i] ‹ a[i-1]
    if (*(array + mid) < *(array + s))
        return azioniACME(array, s, mid);
    return azioniACME(array, mid + 1, e);
}

int minimoIndici(int array[], int s, int e)
{
    if (e == s)
        return 0;

    int mid = (s + e) / 2;
    int left = minimoIndici(array, s, mid);
    int right = minimoIndici(array, mid + 1, e);
    int minTot = min(array, mid + 1, e) - max(array, s, mid);

    int minMet = left < right ? left : right;

    return minMet < minTot ? minMet : minTot;
}

int main()
{

    int table[50][50];
    int costi[] = {2, 13, 4, 5, 9};

    for (int i = 0; i < 50; i++)
        for (int j = 0; j < 50; j++)
            table[i][j] = -1;

    int c[] = {3, 8, 2, 5, 6, 9};
    printf("%d\n", minimoIndici(costi, 0, 4));
}